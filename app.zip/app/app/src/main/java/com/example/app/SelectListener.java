package com.example.app;

import com.example.app.Models.NewsHeadlines;

public interface SelectListener {
    void OnNewsClicked(NewsHeadlines headlines);


}
